#Started: 02/16/2019
#Completed: 02/23/2019

#Sources:

#Honor Pledge: I have not given nor recieved any unauthorized aid.

#########				-SNAKE STRATEGY SIMULATOR-					#########

'''

General Description: This is a snake game/snake strategy simulator made for fun and to test different strategies to play snake. The problem this program solves is finding
the solution to the game snake, and it also adds a bit of spice to the game of snake which can get real boring real fast. This simulator has three game modes as well as 
two strategy simulations for the game. Strategies include the "straight to the apple" strategy and the longest path strategy which goes through a path on the board that 
never intersect itself until the snake's length covers the entire board.

'''

#pygame is used to construct the snake game and random to spawn apples at random locations.

import pygame 
import random

'''

The snake class is responsible for holding all the values of the snake including length, apples eaten, and the squares used to display the snake. The square class is for
the squares used to display the snake on the game screen.

'''
class square () :

	#xdir and ydir represent the direction the square is headed towards, and serial holds the serial number of the square within the snake.

	def __init__ (self, posx, posy, xdir, ydir, serial):
		self.x = posx
		self.y = posy
		self.xdir = xdir
		self.ydir = ydir
		self.serial = serial

class snake () :

	#xdir and ydir hold the direction of the snake, and the squares array holds all the squares that the snake uses.

	def __init__ (self, posx, posy) :
		self.length = 1
		self.eaten = 0
		self.x = posx
		self.y = posy
		self.xdir = 1
		self.ydir = 0
		self.squares = [square(posx, posy, self.xdir, self.ydir, 5)]

	#when increasing length a new square is added to the array with a position right behind the last square.

	def increaseLength(self) :
		self.length += 1
		self.squares.append(square(self.squares[len(self.squares) - 1].x - (10 * self.squares[len(self.squares) - 1].xdir), self.squares[len(self.squares) - 1].y - (10 * self.squares[len(self.squares) - 1].ydir), self.squares[len(self.squares) - 1].xdir, self.squares[len(self.squares) - 1].ydir, self.squares[len(self.squares) - 1].serial + 1))

	#when decreasing length, the last square is removed.

	def decreaseLength(self) :
		if self.length > 0:
			self.length -= 1

		del self.squares[len(self.squares) - 1]

#checkDumb checks if the snake collides with itself.

def checkDumb (snake) :

	for square in snake.squares[1:] :

		if square.x == snake.x and square.y == snake.y :

			return True

	return False

#checkObstacles is used when in autonomous mode for the snake to check if it's going to collide with itself.

def checkObstacles (snake) :

	if snake.xdir == 1 :

		for square in snake.squares :

			if square.y == snake.y and snake.x - square.x <= 10 :

				return True

	elif snake.xdir == -1 :

		for square in snake.squares :

			if square.y == snake.y and square.x - snake.x <= 10 :

				return True

	elif snake.ydir == -1 :

		for square in snake.squares :

			if square.x == snake.x and square.y - snake.y <= 10 :

				return True

	elif snake.ydir == 1 :

		for square in snake.squares :

			if square.x == snake.x and snake.y - square.y <= 10 :

				return True

	return False

#refresh is the function that moves the snake one space further every frame.

def refresh (snake) :

	for i in range(len(snake.squares) - 1) :

		snake.x = snake.squares[0].x 
		snake.y = snake.squares[0].y  

		snake.squares[len(snake.squares) - 1 - i].xdir = snake.squares[len(snake.squares) - 2 - i].xdir
		snake.squares[len(snake.squares) - 1 - i].ydir = snake.squares[len(snake.squares) - 2 - i].ydir

		if snake.squares[len(snake.squares) - 1 - i].xdir == 0 :
			# snake.squares[len(snake.squares) - 1 - i].y = snake.squares[len(snake.squares) - 1 - i].y + (10 * (snake.squares[len(snake.squares) - 1 - i].ydir))
			snake.squares[len(snake.squares) - 1 - i].y = snake.squares[len(snake.squares) - 2 - i].y 

		elif snake.squares[len(snake.squares) - 1 - i].ydir == 0 :
			# snake.squares[len(snake.squares) - 1 - i].x = snake.squares[len(snake.squares) - 1 - i].x + (10 * (snake.squares[len(snake.squares) - 1 - i].xdir))
			snake.squares[len(snake.squares) - 1 - i].x = snake.squares[len(snake.squares) - 2 - i].x   

	snake.squares[0].xdir = snake.xdir
	snake.squares[0].ydir = snake.ydir

	snake.squares[0].x = snake.squares[0].x + (10 * snake.xdir)
	snake.squares[0].y = snake.squares[0].y + (10 * snake.ydir)

	snake.x = snake.squares[0].x 
	snake.y = snake.squares[0].y 

#increaseSnakeLength is for increasing a snake's length multiple times in a row.

def increaseSnakeLength (snake, num) :

	for i in range (num) :
		snake.increaseLength()

#spawnRandomApple is to spawn apples at random locations for the poison apples specifically.

def spawnRandomApple (array, num) :

	for i in range(num) :

		thing = False

		while not thing :

			detect = False

			randthing = [random.randint(0, 49) * 10, random.randint(0, 39) * 10]

			for apple in array :

				if apple == randthing :

					detect = True

					break

			if detect == False :

				array.append(randthing)

			thing = True

#checkGreenApples checks if the snake ate any poison apples.

def checkGreenApples (array, snake) :

	for apple in array :

		if snake.x ==  apple[0] and snake.y == apple[1] :
			snake1.eaten -= 1
			snake1.decreaseLength()
			array.remove(apple)

#length and width hold the screen's dimensions.
width = 500
length = 400

#dim holds the side length for any of the squares that make up the game's grid.
dim = 10

#digit is a check value used later in the game.
digit = 0

#timeInterval is a variable that increments with time; in order to keep track of time.
timeInterval = 0

#greenApples is an array holding all the positions of the green apples so that you don''t have two green apples spawning on the same location.
greenApples = []

pygame.init()

screen = pygame.display.set_mode((width, length))
pygame.display.set_caption("Samboosa")

#gameOverSprite is the text that says: Game Over when you lose.
gameOverSprite = pygame.image.load("download.png")
spriteSential = pygame.image.load("download2.png")

#snake1 is the snake used in all the games/simulations.
snake1 = snake(250, 200) 

#snakeDemo and snakeDemo2 are snakes that move randomly in the main menu just as a visual effect.
snakeDemo = snake(20, 20)

snakeDemo2 = snake(480, 20)

increaseSnakeLength(snakeDemo2, 4)

increaseSnakeLength(snakeDemo, 6)

#done is responsible for turning the main loop on or off
done = False

#gameOver is true when you lose.
gameOver = False

#appleOn tells the game whether or not you've consumed a red apple, which prompts the need to spawn another, and applex and y keep the loction of the red apple.
appleOn = False
applex = 0
appley = 0

#this pygame module needs to be initialized if I were to add any text to this game.
pygame.font.init()

#three sizes of fonts were established for this game, one for headings, one for sub-headings, and a third for side instructions.
myFont = pygame.font.Font('Minecraft.ttf', 29)

myFontSmaller = pygame.font.Font('Minecraft.ttf', 18)

myFontEvenSmaller = pygame.font.Font('Minecraft.ttf', 14)

#first determines whether of not you just entered the game for the first time, so you can be greeted with an initial splash-screen in games not simulations.
first = True

increaseSnakeLength(snake1, 3)

#spriter is used to make some text pulse.
spriter = True

#x holds random values for the snakes in the main menu to move randomly.
x = 1

#auto is used in kids mode to toggle between automatic gameplay and manual gameplay.
auto = False

#These are texts/headings used in the game.
esc = myFontEvenSmaller.render('press esc to main menu', False, (255, 255, 255))

text = myFont.render('SNAKE STRATEGY SIMULATOR', False, (255, 255, 255))

normalGame = myFontSmaller.render('play normal game', False, (255, 255, 255))

longestPath = myFontSmaller.render('longest path strategy', False, (255, 255, 255))

normalAuto = myFontSmaller.render('straight-to-the-apple strategy', False, (255, 255, 255))

noDeath = myFontSmaller.render('kids mode', False, (255, 255, 255))

greenApple = myFontSmaller.render('poison apple mode', False, (38, 213, 44))

toggle = myFontEvenSmaller.render('press spacebar to toggle automatic and manual gameplay', False, (255, 255, 255))

ez = myFont.render('easy', False, (38, 213, 44))

hard = myFont.render('hard', False, (255, 75, 75))

#booleanList helps the program figure out which game mode it's supposed to run.
booleanList = [False, False, False, False, False]

#numbers is used to pulse text in the main menu.
numbers = [True, True, True, True, True]

#numbers2 serves the same job is the choice between easy and hard.
numbers2 = [True, True]

#selected defines which gamemode you've selected.
selected = 0

#selected2 tells if you chose easy or hard.
selected2 = 0

#stage1 helps switch between the main menu and the easy-hard selection menu.
stage1 = True

#easy tells whether or not you chose easy.
easy = False

#mainloop
while not done :

	#initial main menu and easy-hard menu.
	while not done :

		#stage1 means the main menu, if it's false, it goes to the easy-hard menu.
		if stage1 == True :

			#framrate regulator, creates delay every loop
			pygame.time.wait(100)

			#timeInterval increments.
			timeInterval += 1

			#the screen fills with black so that it animates instead of overwriting.
			screen.fill((0, 0, 0))

			#for loop checks if you hit the quit button, to leave the game, the up or down to move through the menu, the return to select the gamemode, which I'll be 
			#referring to as the event loop from now on.
			for event in pygame.event.get():
					if event.type == pygame.QUIT:
						done = True

					if event.type == pygame.KEYDOWN and event.key == pygame.K_UP :
						selected -= 1
						selected = selected % len(numbers)

					elif event.type == pygame.KEYDOWN and event.key == pygame.K_DOWN :
						selected += 1
						selected = selected % len(numbers)

					elif event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN :

						#if simulation modes are selected, the game skips the easy-hard selection screen.
						if selected == 1 or selected == 2 :
							done = True
							booleanList[selected] = True

						else : 
							booleanList[selected] = True
							stage1 = False


			#all non-selected elements of the numbers array are true, except for the one selected, which pulses between true and false, for it to pulse on the screen
			#the user know that it's selected.

			for i in range(len(numbers)) :

				if i != selected :
					
					numbers[i] = True

			#main title

			screen.blit(text, (30, 10))

			#the selected element pulses between true and false, to pulse on-screen due to the if-statement(s) following this one.

			if timeInterval % 20 : 

				numbers[selected] = not numbers[selected]

			if numbers[0] == True :

				screen.blit(normalGame, (175, 130))

			if numbers[1] == True :

				screen.blit(longestPath, (160, 160))

			if numbers[2] == True :

				screen.blit(normalAuto, (125, 190))

			if numbers[3] == True :

				screen.blit(noDeath, (215, 220))

			if numbers[4] == True :

				screen.blit(greenApple, (180, 250))

			#This if statement changes the demo snakes' direction every few seconds so that they move in random directions, and not every second because the snakes start
			#to look more like worms then.

			if timeInterval % 5 == 0 :

				x = random.randint(1, 4)

				if x == 1 :
					snakeDemo.ydir = -1
					snakeDemo.xdir = 0

				elif x == 2 :
					snakeDemo.ydir = 1
					snakeDemo.xdir = 0

				elif x == 3 :
					snakeDemo.ydir = 0
					snakeDemo.xdir = -1

				elif x == 4:
					snakeDemo.ydir = 0
					snakeDemo.xdir = 1

			#the other snake changes at different intervals because it looks as if they're tethered together when they change direction at the same time everytime.

			if timeInterval % 6 == 0 :

				x = random.randint(1, 4)

				if x == 1 :
					snakeDemo2.ydir = -1
					snakeDemo2.xdir = 0

				elif x == 2 :
					snakeDemo2.ydir = 1
					snakeDemo2.xdir = 0

				elif x == 3 :
					snakeDemo2.ydir = 0
					snakeDemo2.xdir = -1

				elif x == 4:
					snakeDemo2.ydir = 0
					snakeDemo2.xdir = 1

			#keeps the snakes moving.

			refresh(snakeDemo)

			refresh(snakeDemo2)

			#makes the snakes pop on the other side so that they don't go off-screen.

			if snakeDemo.x >= 500  :
				snakeDemo.x = 0
				snakeDemo.squares[0].x = 0

			elif snakeDemo.x < 0 :
				snakeDemo.x = 490
				snakeDemo.squares[0].x = 490

			elif snakeDemo.y < 0 :
				snakeDemo.y = 390
				snakeDemo.squares[0].y = 390

			elif snakeDemo.y >= 400 :
				snakeDemo.y = 0
				snakeDemo.squares[0].y = 0

			if snakeDemo2.x >= 500  :
				snakeDemo2.x = 0
				snakeDemo2.squares[0].x = 0

			elif snakeDemo2.x < 0 :
				snakeDemo2.x = 490
				snakeDemo2.squares[0].x = 490

			elif snakeDemo2.y < 0 :
				snakeDemo2.y = 390
				snakeDemo2.squares[0].y = 390

			elif snakeDemo2.y >= 400 :
				snakeDemo2.y = 0
				snakeDemo2.squares[0].y = 0

			#puts all the snakes' squares on screen (visual representation).

			for i in snakeDemo.squares :

				pygame.draw.rect(screen, (255, 255, 255), pygame.Rect(i.x, i.y, dim, dim))

			for i in snakeDemo2.squares :

				pygame.draw.rect(screen, (255, 255, 255), pygame.Rect(i.x, i.y, dim, dim))

			pygame.display.update()

		else: 

			#this is the easy-hard menu for the gameplay modes, not the simulation modes.

			screen.fill((0, 0, 0))

			screen.blit(esc, (10, 10))

			#an event loop is needed here with an extra escape option that returns you to the main menu.

			for event in pygame.event.get():

				if event.type == pygame.QUIT:
					done = True
					booleanList[selected] = False

				if event.type == pygame.KEYDOWN and event.key == pygame.K_UP :
					selected2 -= 1
					selected2 = selected2 % len(numbers2)

				elif event.type == pygame.KEYDOWN and event.key == pygame.K_DOWN :
					selected2 += 1
					selected2 = selected2 % len(numbers2)

				elif event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN :
					done = True
					if selected2 == 0 :
						easy = True
					else: 
						easy = False

					stage1 = True

				elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE :
					done = False
					stage1 = True
					booleanList[selected] = False

			timeInterval += 1

			#same pulsing algorithm for this menu.

			for i in range(len(numbers2)) :

				if i != selected2 :
					
					numbers2[i] = True

			if timeInterval % 5 == 0 : 

				numbers2[selected2] = not numbers2[selected2]

			if numbers2[0] == True :

				screen.blit(ez, (210, 180))

			if numbers2[1] == True :

				screen.blit(hard, (210, 220))

			pygame.display.update()


	#this is mode 0, which is the standard snake game we all know.
	while booleanList[0]:

		#easy adds a delay making the snake go slower, making the game easier.
		if easy == True :

			pygame.time.wait(10)

		#If first, the game has an initial splash screen for the player to be ready.
		if first == True :

			timeInterval += 1

			screen.fill((0, 0, 0))

			#event loop that has the game start, or, in other words, makes first false if you hit a random key, but goes back to the main menu if you hit escape.
			for event in pygame.event.get():
				if event.type == pygame.QUIT:
					booleanList[0] = False

				elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE :
					booleanList[0] = False
					done = False
					snake1 = snake(250, 200)
					increaseSnakeLength(snake1, 3)

				elif event.type == pygame.KEYDOWN:
					first = False

			#same pulsing algorithm for the "press any key to start" text.
			if timeInterval % 8 == 0 :
				spriter = not spriter	

			screen.blit(esc, (10, 10))		
			
			if spriter == True :
				screen.blit(spriteSential, (197, 230))

			pygame.display.update()


		#this is the game over splash screen which is like the first screen but has "GAME OVER" on it and your score.
		elif gameOver == True :

			for event in pygame.event.get():
				if event.type == pygame.QUIT:
					booleanList[0] = False

				elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE :
					booleanList[0] = False
					done = False
					snake1 = snake(250, 200)
					increaseSnakeLength(snake1, 3)

				elif event.type == pygame.KEYDOWN:
					gameOver = False

			timeInterval += 1
			screen.fill((0, 0, 0))
			screen.blit(gameOverSprite, (135, 60))
			screen.blit(score, (215, 240))
			screen.blit(esc, (10, 10))

			if timeInterval % 8 == 0 :
				spriter = not spriter			

			if spriter == True :
				screen.blit(spriteSential, (197, 230))

			pygame.display.update()


		#This is the game's main loop where you actually play the game.
		else :

			screen.fill((0, 0, 0))

			#the event loop has conditions for up, down, left, and right to change the snake's direction which is only allowed once every frame. Escape resets the snake
			#and returns to the main menu so that when you play other modes, you start with the same snake.
			for event in pygame.event.get():
				if event.type == pygame.QUIT:
					booleanList[0] = False

				elif event.type == pygame.KEYDOWN and event.key == pygame.K_UP and snake1.ydir != 1 :
					snake1.ydir = -1
					snake1.xdir = 0

				elif event.type == pygame.KEYDOWN and event.key == pygame.K_DOWN and snake1.ydir != -1 :
					snake1.ydir = 1
					snake1.xdir = 0

				elif event.type == pygame.KEYDOWN and event.key == pygame.K_LEFT and snake1.xdir != 1 :
					snake1.ydir = 0
					snake1.xdir = -1

				elif event.type == pygame.KEYDOWN and event.key == pygame.K_RIGHT and snake1.xdir != -1:
					snake1.ydir = 0
					snake1.xdir = 1

				elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE :
					booleanList[0] = False
					done = False
					snake1 = snake(250, 200)
					increaseSnakeLength(snake1, 3)


			#this if-statement adds a randomly placed apple if the previous one was eaten.
			if appleOn == False :
				applex = (random.randint(0, 49) * 10)
				appley = (random.randint(0, 39) * 10)
				appleOn = True

			refresh(snake1)

			#placing the visual of the apple on the screen.
			pygame.draw.rect(screen, (255, 75, 75), pygame.Rect(applex, appley, dim, dim))

			#"drawing" the snake every frame.
			for i in snake1.squares :

				pygame.draw.rect(screen, (255, 255, 255), pygame.Rect(i.x, i.y, dim, dim))

			timeInterval += 1

			#checks if the snake ate the apple.
			if snake1.x == applex and snake1.y == appley :
				appleOn = False
				snake1.eaten += 1
				snake1.increaseLength()

			timeInterval += 1

			#game over conditions include colliding with a wall or with the snake itself.
			if snake1.x >= 500 or snake1.x < 0 or snake1.y >= 400 or snake1.y < 0 or checkDumb(snake1) == True :
				gameOver = True 
				appleOn = False
				score = myFontSmaller.render('score: ' + str(snake1.eaten), False, (255, 255, 255))
				snake1 = snake(250, 200)
				increaseSnakeLength(snake1, 3)
				timeInterval = 0
			
			pygame.display.update()

	#first is changed to true after every loop so that you're met with the splash screen even if you change game modes.
	first = True

	#mode 1 is the longest path strategy which follows a path that covers the entire grid without intersecting itself.
	while booleanList[1]:

		#There is no splash screen for this mode because it's a simulation.
		if gameOver == True :

			for event in pygame.event.get():
				if event.type == pygame.QUIT:
					done = True
					booleanList[1] = False

				elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE :
					booleanList[1] = False
					done = False
					stage1 = True
					snake1 = snake(250, 200)
					increaseSnakeLength(snake1, 3)

				elif event.type == pygame.KEYDOWN:
					gameOver = False

			timeInterval += 1
			screen.fill((0, 0, 0))
			screen.blit(gameOverSprite, (135, 60))
			screen.blit(score, (215, 240))
			screen.blit(esc, (10, 10))

			if timeInterval % 8 == 0 :
				spriter = not spriter			

			if spriter == True :
				screen.blit(spriteSential, (197, 230))

			pygame.display.update()

		else :

			screen.fill((0, 0, 0))

			for event in pygame.event.get():
				if event.type == pygame.QUIT:
					done = True
					booleanList[1] = False

				elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE :
					booleanList[1] = False
					done = False
					snake1 = snake(250, 200)
					increaseSnakeLength(snake1, 3)

			#these if statements make the snake follow the path initially set without regard for the apple's location, aside from that and the fact that the arrow keys
			#don't control the snake, this mode is the same as the previous one
			if snake1.x == 490 and digit == 0 :

				snake1.xdir = 0
				snake1.ydir = 1
				digit = 1

			elif digit == 1 and snake1.x == 490 :

				snake1.xdir = -1
				snake1.ydir = 0
				digit = 0

			elif snake1.x == 10 and snake1.xdir == -1 and snake1.y != 390 :

				snake1.ydir = 1
				snake1.xdir = 0
				digit += 1

			elif digit == 1 and snake1.x == 10:

				snake1.ydir = 0
				snake1.xdir = 1
				digit = 0

			elif snake1.x == 0 and snake1.y == 390 :

				snake1.ydir = -1
				snake1.xdir = 0

			elif snake1.x == 0 and snake1.y == 0 :

				snake1.xdir = 1 
				snake1.ydir = 0

			if appleOn == False :
				applex = (random.randint(0, 49) * 10)
				appley = (random.randint(0, 39) * 10)
				appleOn = True

			
			refresh(snake1)

			pygame.draw.rect(screen, (255, 75, 75), pygame.Rect(applex, appley, dim, dim))

			for i in snake1.squares :

				pygame.draw.rect(screen, (255, 255, 255), pygame.Rect(i.x, i.y, dim, dim))

			key = pygame.key.get_pressed()

			if snake1.x == applex and snake1.y == appley :
				appleOn = False
				snake1.eaten += 1
				snake1.increaseLength()

			timeInterval += 1

			if snake1.x >= 500 or snake1.x < 0 or snake1.y >= 400 or snake1.y < 0 or checkDumb(snake1) == True :
				gameOver = True 
				appleOn = False
				score = myFontSmaller.render('score: ' + str(snake1.eaten), False, (255, 255, 255))
				snake1 = snake(250, 200)
				increaseSnakeLength(snake1, 3)
				timeInterval = 0
			
			pygame.display.update()

	first = True

	#mode 2 is the straight to the apple strategy, which is same as the normal game but without keys controlling the snake, with an algorithm that controls the snake 
	#instead.
	while booleanList[2]:

		#no first screen, same as the last mode.
		if gameOver == True :

			for event in pygame.event.get():
				if event.type == pygame.QUIT:
					booleanList[2] = False

				elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE :
					booleanList[2] = False
					done = False
					snake1 = snake(250, 200)
					increaseSnakeLength(snake1, 3)

				elif event.type == pygame.KEYDOWN:
					gameOver = False

			timeInterval += 1
			screen.fill((0, 0, 0))
			screen.blit(gameOverSprite, (135, 60))
			screen.blit(score, (215, 240))
			screen.blit(esc, (10, 10))

			if timeInterval % 8 == 0 :
				spriter = not spriter			

			if spriter == True :
				screen.blit(spriteSential, (197, 230))

			pygame.display.update()

		else :

			screen.fill((0, 0, 0))

			for event in pygame.event.get():
				if event.type == pygame.QUIT:
					booleanList[2] = False

				elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE :
					booleanList[2] = False
					done = False
					snake1 = snake(250, 200)
					increaseSnakeLength(snake1, 3)

			if appleOn == False :
				applex = (random.randint(0, 49) * 10)
				appley = (random.randint(0, 39) * 10)
				appleOn = True


			#this is the start of the automatic algorithm, which makes the snake head in the direction of the apple.
			if applex > snake1.x :

				if snake1.xdir == -1 :
					snake1.xdir = 0
					snake1.ydir = 1

				else :

					snake1.xdir = 1
					snake1.ydir = 0

			elif applex < snake1.x :

				if snake1.xdir == 1 :

					snake1.xdir = 0
					snake1.ydir = 1

				else :

					snake1.xdir = -1
					snake1.ydir = 0

			elif applex == snake1.x :

				if appley > snake1.y :

					if snake1.ydir == -1 :
						snake1.xdir = 1
						snake1.ydir = 0

					else :

						snake1.xdir = 0
						snake1.ydir = 1

				elif appley < snake1.y :

					if snake1.ydir == 1 :

						snake1.xdir = 1
						snake1.ydir = 0

					else :

						snake1.xdir = 0
						snake1.ydir = -1

			#this part tries to stop the snake from running into itself.

			if checkObstacles(snake1) == True :

				if snake1.ydir == 0 :

					snake1.ydir == 1
					snake1.xdir == 0

					if checkObstacles(snake1) == True :

						snake1.ydir == -1

				elif snake1.xdir == 0 :

					snake1.xdir == 1
					snake1.ydir == 0

					if checkObstacles(snake1) == True :

						snake1.xdir == -1

			#this is the ennd of the automatic algorithm.

			refresh(snake1)

			pygame.draw.rect(screen, (255, 75, 75), pygame.Rect(applex, appley, dim, dim))

			for i in snake1.squares :

				pygame.draw.rect(screen, (255, 255, 255), pygame.Rect(i.x, i.y, dim, dim))

			key = pygame.key.get_pressed()

			timeInterval += 1

			if snake1.x == applex and snake1.y == appley :
				appleOn = False
				snake1.eaten += 1
				snake1.increaseLength()

			if snake1.x >= 500 or snake1.x < 0 or snake1.y >= 400 or snake1.y < 0 or checkDumb(snake1) == True :
				gameOver = True 
				appleOn = False
				score = myFontSmaller.render('score: ' + str(snake1.eaten), False, (255, 255, 255))
				snake1 = snake(250, 200)
				increaseSnakeLength(snake1, 3)
				timeInterval = 0
			
			pygame.display.update()

	first = True

	#mode 3 is kids mode, where there is no way to die, and you can toggle between automatic and manual control. 
	#in this mode, you can go through walls which will get you to the other side, and you can go through yourself.
	#the contents of this mode are the same as the normal game, but all game over conditions are removed, and the snake transports to the opposite wall if it goes through
	#wall.
	while booleanList[3]:

		if easy == True :

			pygame.time.wait(10)

		#there is no game over screen.
		if first == True :

			timeInterval += 1

			screen.fill((0, 0, 0))

			for event in pygame.event.get():
				if event.type == pygame.QUIT:
					booleanList[3] = False

				elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE :
					booleanList[3] = False
					done = False
					snake1 = snake(250, 200)
					increaseSnakeLength(snake1, 3)

				elif event.type == pygame.KEYDOWN:
					first = False

			screen.blit(esc, (10, 10))
			screen.blit(toggle, (10, 30))

			if timeInterval % 8 == 0 :
				spriter = not spriter			
			
			if spriter == True :
				screen.blit(spriteSential, (197, 230))

			pygame.display.update()

		else :

			pygame.time.wait(10)

			screen.fill((0, 0, 0))

			#the event loop includes switching between auto and manual control using the spacebar.
			for event in pygame.event.get():
				if event.type == pygame.QUIT:
					booleanList[4] = False

				if event.type == pygame.KEYDOWN and event.key == pygame.K_UP and snake1.ydir != 1 :
					snake1.ydir = -1
					snake1.xdir = 0

				elif event.type == pygame.KEYDOWN and event.key == pygame.K_DOWN and snake1.ydir != -1 :
					snake1.ydir = 1
					snake1.xdir = 0

				elif event.type == pygame.KEYDOWN and event.key == pygame.K_LEFT and snake1.xdir != 1 :
					snake1.ydir = 0
					snake1.xdir = -1

				elif event.type == pygame.KEYDOWN and event.key == pygame.K_RIGHT and snake1.xdir != -1:
					snake1.ydir = 0
					snake1.xdir = 1

				#auto is toggled if teh spacebar is pressed. It's initially off.
				elif event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
					auto = not auto

				elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE :
					booleanList[3] = False
					done = False
					snake1 = snake(250, 200)
					increaseSnakeLength(snake1, 3)

			if appleOn == False :
				applex = (random.randint(0, 49) * 10)
				appley = (random.randint(0, 39) * 10)
				appleOn = True

			#the same algorithm used in the straight to the apple mode but only if auto is true.
			if auto == True:

				if applex > snake1.x :

					if snake1.xdir == -1 :
						snake1.xdir = 0
						snake1.ydir = 1

					else :

						snake1.xdir = 1
						snake1.ydir = 0

				elif applex < snake1.x :

					if snake1.xdir == 1 :

						snake1.xdir = 0
						snake1.ydir = 1

					else :

						snake1.xdir = -1
						snake1.ydir = 0

				elif applex == snake1.x :

					if appley > snake1.y :

						if snake1.ydir == -1 :
							snake1.xdir = 1
							snake1.ydir = 0

						else :

							snake1.xdir = 0
							snake1.ydir = 1

					elif appley < snake1.y :

						if snake1.ydir == 1 :

							snake1.xdir = 1
							snake1.ydir = 0

						else :

							snake1.xdir = 0
							snake1.ydir = -1

				if checkObstacles(snake1) == True :

					if snake1.ydir == 0 :

						snake1.ydir == 1
						snake1.xdir == 0

						if checkObstacles(snake1) == True :

							snake1.ydir == -1

					elif snake1.xdir == 0 :

						snake1.xdir == 1
						snake1.ydir == 0

						if checkObstacles(snake1) == True :

							snake1.xdir == -1

			refresh(snake1)

			pygame.draw.rect(screen, (255, 75, 75), pygame.Rect(applex, appley, dim, dim))

			for i in snake1.squares :

				pygame.draw.rect(screen, (255, 255, 255), pygame.Rect(i.x, i.y, dim, dim))

			key = pygame.key.get_pressed()

			#this series of if-statements transports the snake to the opposite wall if it goes through a wall.
			if snake1.x >= 500  :
				snake1.x = 0
				snake1.squares[0].x = 0

			elif snake1.x < 0 :
				snake1.x = 490
				snake1.squares[0].x = 490

			elif snake1.y < 0 :
				snake1.y = 390
				snake1.squares[0].y = 390

			elif snake1.y >= 400 :
				snake1.y = 0
				snake1.squares[0].y = 0

			if snake1.x == applex and snake1.y == appley :
				appleOn = False
				snake1.eaten += 1
				snake1.increaseLength()

			timeInterval += 1
			
			pygame.display.update()

	first = True

	#mode 4 is poison apple mode, which is like the normal mode, but it has poison (green) apples. Poison apples decrese your length if you eat them, and if your length 
	#reaches 0, you lose. For each red apple that you eat, an extra green apple spawns, so there are always enough green apples to kill you.
	while booleanList[4]:

		#in this mode, easy mode means there's only one extra poison apple added if you eat a red apple, but hard mode adds two for every red apple.
		if easy == True :

			applesAdded = 1 

		else :

			applesAdded = 2

		pygame.time.wait(10)

		if first == True :

			timeInterval += 1

			screen.fill((0, 0, 0))

			for event in pygame.event.get():
				if event.type == pygame.QUIT:
					booleanList[4] = False

				elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE :
					booleanList[4] = False
					done = False
					snake1 = snake(250, 200)
					increaseSnakeLength(snake1, 3)

				#each time the game starts, both in the first time and after the game over, the greenApples list is reset and 4 new apples are spawned.
				elif event.type == pygame.KEYDOWN:
					first = False
					greenApples = []
					spawnRandomApple(greenApples, 4 - applesAdded)

			screen.blit(esc, (10, 10))

			if timeInterval % 8 == 0 :
				spriter = not spriter			
			
			if spriter == True :
				screen.blit(spriteSential, (197, 230))

			pygame.display.update()


		#it's possible for your score to be negative if you've eaten more green apples than red apples.
		elif gameOver == True :

			for event in pygame.event.get():
				if event.type == pygame.QUIT:
					booleanList[4] = False

				elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE :
					booleanList[4] = False
					done = False
					snake1 = snake(250, 200)
					increaseSnakeLength(snake1, 3)

				elif event.type == pygame.KEYDOWN:
					gameOver = False
					greenApples = []
					spawnRandomApple(greenApples, 4 - applesAdded)

			timeInterval += 1
			screen.fill((0, 0, 0))
			screen.blit(gameOverSprite, (135, 60))
			screen.blit(score, (215, 240))
			screen.blit(esc, (10, 10))

			if timeInterval % 8 == 0 :
				spriter = not spriter			

			if spriter == True :
				screen.blit(spriteSential, (197, 230))

			pygame.display.update()

		else :

			screen.fill((0, 0, 0))

			for event in pygame.event.get():
				if event.type == pygame.QUIT:
					booleanList[4] = False

				if event.type == pygame.KEYDOWN and event.key == pygame.K_UP and snake1.ydir != 1 :
					snake1.ydir = -1
					snake1.xdir = 0

				elif event.type == pygame.KEYDOWN and event.key == pygame.K_DOWN and snake1.ydir != -1 :
					snake1.ydir = 1
					snake1.xdir = 0

				elif event.type == pygame.KEYDOWN and event.key == pygame.K_LEFT and snake1.xdir != 1 :
					snake1.ydir = 0
					snake1.xdir = -1

				elif event.type == pygame.KEYDOWN and event.key == pygame.K_RIGHT and snake1.xdir != -1:
					snake1.ydir = 0
					snake1.xdir = 1

				elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE :
					booleanList[4] = False
					done = False
					snake1 = snake(250, 200)
					increaseSnakeLength(snake1, 3)

			if appleOn == False :
				applex = (random.randint(0, 49) * 10)
				appley = (random.randint(0, 39) * 10)

				#poison apples are spawned every time a red apple is consumed.
				spawnRandomApple(greenApples, applesAdded)
				appleOn = True

			#"drawing" the green apples.
			for apple in greenApples :

				pygame.draw.rect(screen, (38, 213, 44), pygame.Rect(apple[0], apple[1], dim, dim))

			#checks for eaten green apples by the snake. The function also decreases the snake's length if it has eaten an apple
			checkGreenApples(greenApples, snake1)

			pygame.draw.rect(screen, (255, 75, 75), pygame.Rect(applex, appley, dim, dim))

			for i in snake1.squares :

				pygame.draw.rect(screen, (255, 255, 255), pygame.Rect(i.x, i.y, dim, dim))

			timeInterval += 1

			if snake1.x == applex and snake1.y == appley :
				appleOn = False
				snake1.eaten += 1
				snake1.increaseLength()

			#A condition is added to the game over loop, that states that if a snake's length reaches zero, the game over loop is activated. 
			if snake1.x >= 500 or snake1.x < 0 or snake1.y >= 400 or snake1.y < 0 or checkDumb(snake1) == True or snake1.length == 0 :
				gameOver = True 
				appleOn = False
				score = myFontSmaller.render('score: ' + str(snake1.eaten), False, (255, 255, 255))
				snake1 = snake(250, 200)
				increaseSnakeLength(snake1, 3)
				timeInterval = 0
				
			refresh(snake1)
			
			pygame.display.update()

pygame.quit()

#The End

#Thank you!
